const getAverage = (a, b, c) => (a + b + c) / 3
